# These details are available on the first MySQL Workbench screen
# Usually called 'Local Instance'
dbuser = "root" #PUT YOUR MySQL username here - usually root
dbpass = "1234" #PUT YOUR PASSWORD HERE
dbhost = "localhost" 
dbport = "3306"
dbname = "pythonlogin"